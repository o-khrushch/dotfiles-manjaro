#!/bin/sh -e

LIBRARY_INSTALL_PATH="/opt/iit/eu/sw"

NPAPI_PLUGIN_NAME="npeuscp.so"
NPAPI_PLUGIN_INSTALL_PATH="/usr/lib/mozilla/plugins"
NPAPI_PLUGIN_INSTALL_PATH_X64="/usr/lib/mozilla/plugins"

NMH_APP_NAME="euscpnmh"

unistall_npapi() {
  local install_path=$NPAPI_PLUGIN_INSTALL_PATH
  if [ -d "/usr/lib64" ]; then
    install_path=$NPAPI_PLUGIN_INSTALL_PATH_X64
  fi

  local file_path=$install_path/$NPAPI_PLUGIN_NAME
  if [ -f $file_path ]; then
    unlink $file_path
  fi
}

unistall_nmh() {
	$LIBRARY_INSTALL_PATH/$NMH_APP_NAME /unistall
}

unistall_npapi
unistall_nmh

exit 0
